import {FilterForm} from "@/features/components/filterForm.tsx";

export function HomePage() {
  return <FilterForm/>
}